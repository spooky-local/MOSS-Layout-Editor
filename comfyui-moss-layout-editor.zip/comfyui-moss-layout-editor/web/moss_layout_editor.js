// MOSS Layout Editor — a bounding-box layout editor for MOSS-Image in ComfyUI.
// Boxes are stored as fractions of the canvas (0..1, top-left origin) in the
// hidden "layout_data" widget, so they follow the image when the size changes.

import { app } from "../../scripts/app.js";

const NODE_NAME = "MossLayoutEditor";
const LABELS = [
  ["object", "Object"],
  ["character", "Character"],
  ["text", "Text"],
];
const PRESETS = [
  ["1:1", 1024, 1024],
  ["3:4", 864, 1152],
  ["4:3", 1152, 864],
  ["2:3", 832, 1248],
  ["3:2", 1248, 832],
  ["9:16", 768, 1344],
  ["16:9", 1344, 768],
];
const HANDLE = 7; // handle hit radius in screen px
const MIN_PX = 4; // smallest box, in image px
const UNDO_LIMIT = 150;

// ───────────────────────── state helpers ─────────────────────────

const clamp01 = (v) => Math.min(1, Math.max(0, Number.isFinite(+v) ? +v : 0));
const snap16 = (v) => Math.max(16, Math.floor((Number(v) || 1024) / 16 + 0.5) * 16);
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

function defaultState() {
  return { v: 1, nextId: 1, boxes: [] };
}

function normalizeBox(b, fallbackId) {
  const [x0, x1] = [clamp01(b.x0), clamp01(b.x1)].sort((a, c) => a - c);
  const [y0, y1] = [clamp01(b.y0), clamp01(b.y1)].sort((a, c) => a - c);
  return {
    id: Number.isInteger(b.id) && b.id > 0 ? b.id : fallbackId,
    name: String(b.name ?? ""),
    label: LABELS.some(([k]) => k === b.label) ? b.label : "object",
    caption: String(b.caption ?? ""),
    text: String(b.text ?? ""),
    enabled: b.enabled !== false,
    x0, y0, x1, y1,
  };
}

function parseState(str) {
  try {
    const s = JSON.parse(str || "");
    if (s && Array.isArray(s.boxes)) {
      const boxes = s.boxes.filter((b) => b && typeof b === "object").map((b, i) => normalizeBox(b, 1000 + i));
      const nextId = Math.max(Number(s.nextId) || 1, ...boxes.map((b) => b.id + 1), 1);
      return { v: 1, nextId, boxes };
    }
  } catch (_) {
    /* fall through */
  }
  return defaultState();
}

function boxColor(id, alpha, light = 65) {
  const hue = Math.round((id * 137.508 + 320) % 360);
  return `hsla(${hue}, 85%, ${light}%, ${alpha})`;
}

function boxTitle(b) {
  return (b.name || "").trim() || (b.caption || "").trim().split("\n")[0] || (b.label === "text" && b.text.trim()) || "";
}

/** Problems that stop a box being sent, or worth a warning. */
function boxIssue(b) {
  const caption = (b.caption || "").trim() || (b.name || "").trim();
  if (b.label === "text" && !(b.text || "").trim()) return "Text box has no text to render";
  if (!caption && !(b.label === "text" && (b.text || "").trim())) return "No description — this box won't be sent";
  return "";
}

// Same maths as nodes.py (and ComfyUI's core MOSS-Image Layout Prompt node).
function edge(frac, size, ceil) {
  const px = Number((frac * size).toFixed(9));
  return (ceil ? Math.ceil(px) : Math.floor(px)) - Math.floor(size / 2);
}

function buildLayout(state, summary, W, H) {
  const items = [];
  for (const b of state.boxes) {
    if (!b.enabled || b.x1 - b.x0 <= 0 || b.y1 - b.y0 <= 0) continue;
    const caption = (b.caption || "").trim() || (b.name || "").trim();
    const text = (b.text || "").trim();
    if (!caption && !(b.label === "text" && text)) continue;
    const item = { label: b.label, caption };
    if (b.label === "text") item.text = text;
    item.bbox = [edge(b.y0, H, false), edge(b.x0, W, false), edge(b.y1, H, true), edge(b.x1, W, true)];
    items.push(item);
  }
  const s = (summary || "").trim();
  if (!items.length) return { text: s, count: 0 };
  const layout = { summary: { caption: s }, items, bbox_coord_space: "abs_centralized", bbox_format: "yxyx" };
  return { text: JSON.stringify(layout), count: items.length };
}

// ───────────────────────── node / widget helpers ─────────────────────────

const getWidget = (node, name) => node.widgets?.find((w) => w.name === name);

function getLink(graph, id) {
  if (id == null || !graph) return null;
  if (typeof graph.getLink === "function") return graph.getLink(id);
  const links = graph.links;
  return links?.get?.(id) ?? links?.[id] ?? null;
}

/** If width/height is fed by a link, try to read the number on the other end. */
function linkedNumber(node, name) {
  const input = node.inputs?.find((i) => i.name === name || i.widget?.name === name);
  if (!input || input.link == null) return undefined;
  const link = getLink(node.graph, input.link);
  const origin = link && node.graph?.getNodeById?.(link.origin_id);
  if (!origin?.widgets) return undefined;
  const outName = origin.outputs?.[link.origin_slot]?.name;
  const byName = origin.widgets.find((w) => w.name === outName && typeof w.value === "number");
  if (byName) return byName.value;
  const numeric = origin.widgets.filter((w) => typeof w.value === "number");
  return numeric.length === 1 ? numeric[0].value : undefined;
}

function getDims(node) {
  const w = linkedNumber(node, "width") ?? getWidget(node, "width")?.value;
  const h = linkedNumber(node, "height") ?? getWidget(node, "height")?.value;
  return [snap16(w), snap16(h)];
}

function setWidgetValue(node, name, value) {
  const w = getWidget(node, name);
  if (!w || w.value === value) return;
  w.value = value;
  try {
    w.callback?.(value, app.canvas, node);
  } catch (e) {
    console.warn("[MOSS Layout Editor]", e);
  }
}

function hideWidget(w) {
  if (!w) return;
  w.hidden = true;
  w.options = w.options || {};
  w.options.hidden = true;
  w.computeSize = () => [0, -4];
  w.computeLayoutSize = () => ({ minHeight: 0, maxHeight: 0, minWidth: 0 });
  if (w.element) w.element.style.display = "none";
  if (w.inputEl) w.inputEl.style.display = "none";
}

function markChanged(node) {
  node.setDirtyCanvas?.(true, true);
  node.graph?.setDirtyCanvas?.(true, true);
  try {
    app.extensionManager?.workflow?.activeWorkflow?.changeTracker?.checkState?.();
  } catch (_) {
    /* older frontends */
  }
}

// ───────────────────────── styles ─────────────────────────

const CSS = `
.mle-preview{display:flex;flex-direction:column;gap:6px;width:100%;height:100%;box-sizing:border-box;padding:2px 0 4px;font:12px system-ui,sans-serif;color:#d8d8de}
.mle-preview button{all:unset;cursor:pointer;text-align:center;padding:7px 10px;border-radius:7px;background:#ff8fd1;color:#1d1220;font-weight:650;font-size:12.5px}
.mle-preview button:hover{background:#ffa9dc}
.mle-preview .mle-pv-wrap{flex:1;min-height:90px;position:relative;cursor:pointer}
.mle-preview canvas{position:absolute;inset:0;width:100%;height:100%}
.mle-preview .mle-pv-info{color:#a6a6b2;font-size:11.5px;text-align:center;line-height:1.35}
.mle-preview .mle-pv-info b{color:#e8e8ee;font-weight:600}
.mle-preview .mle-pv-warn{color:#ffcf6e}

.mle-overlay{position:fixed;inset:0;z-index:100000;background:rgba(6,6,10,.72);display:flex;align-items:center;justify-content:center;font:13px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;color:#e6e6ea}
.mle-win{width:min(1500px,96vw);height:min(980px,94vh);background:#17171c;border:1px solid #2f2f38;border-radius:12px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.6)}
.mle-head{display:flex;align-items:center;gap:14px;flex-wrap:wrap;padding:10px 14px;border-bottom:1px solid #2a2a33;background:#1c1c22}
.mle-title{font-weight:700;font-size:14px;letter-spacing:.2px;margin-right:4px}
.mle-title span{color:#ff8fd1}
.mle-grp{display:flex;align-items:center;gap:6px}
.mle-grp label{color:#a8a8b4;font-size:12px}
.mle-sp{flex:1}
.mle-win input[type=number],.mle-win input[type=text],.mle-win select,.mle-win textarea{background:#101014;color:#ececf1;border:1px solid #33333d;border-radius:6px;padding:5px 7px;font:inherit;box-sizing:border-box}
.mle-win input[type=number]{width:72px}
.mle-win textarea{width:100%;resize:vertical;min-height:54px}
.mle-win input:focus,.mle-win select:focus,.mle-win textarea:focus{outline:none;border-color:#ff8fd1}
.mle-btn{all:unset;cursor:pointer;padding:6px 11px;border-radius:7px;background:#2a2a33;color:#e6e6ea;font-size:12.5px;font-weight:550;display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
.mle-btn:hover{background:#363642}
.mle-btn:disabled,.mle-btn[disabled]{opacity:.4;cursor:default}
.mle-btn.primary{background:#ff8fd1;color:#1d1220;font-weight:700}
.mle-btn.primary:hover{background:#ffa9dc}
.mle-btn.danger:hover{background:#5a2330;color:#ffd1da}
.mle-chk{display:inline-flex;align-items:center;gap:5px;color:#c9c9d3;font-size:12.5px;cursor:pointer;user-select:none}
.mle-chk input{accent-color:#ff8fd1}
.mle-body{flex:1;display:flex;min-height:0}
.mle-stage{flex:1;min-width:0;position:relative;display:flex;align-items:center;justify-content:center;background:#0e0e12;padding:18px}
.mle-stage canvas{display:block;touch-action:none;box-shadow:0 0 0 1px #34343f}
.mle-dims{position:absolute;left:12px;bottom:10px;color:#9a9aa6;font-size:12px;background:rgba(14,14,18,.85);padding:3px 8px;border-radius:6px}
.mle-side{width:360px;flex:none;border-left:1px solid #2a2a33;overflow-y:auto;background:#19191e}
.mle-sec{padding:12px 14px;border-bottom:1px solid #26262e}
.mle-sec h4{margin:0 0 8px;font-size:11.5px;letter-spacing:.6px;text-transform:uppercase;color:#9d9daa;font-weight:650;display:flex;align-items:center;gap:8px}
.mle-sec h4 .mle-count{color:#ff8fd1}
.mle-help{color:#8d8d99;font-size:12px;margin:6px 0 0}
.mle-list{display:flex;flex-direction:column;gap:4px}
.mle-row{display:flex;align-items:center;gap:7px;padding:6px 6px 6px 8px;border-radius:7px;background:#202027;border:1px solid transparent;cursor:pointer}
.mle-row:hover{background:#26262e}
.mle-row.sel{border-color:#ff8fd1;background:#2a2230}
.mle-row.off .mle-row-title,.mle-row.off .mle-num{opacity:.45;text-decoration:line-through}
.mle-num{flex:none;font:700 11px ui-monospace,monospace;padding:2px 5px;border-radius:4px;color:#141418}
.mle-row-title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mle-row-title i{color:#7f7f8c}
.mle-chip{flex:none;font-size:10.5px;padding:1px 6px;border-radius:9px;background:#30303a;color:#bdbdc8}
.mle-warn{flex:none;color:#ffcf6e;font-weight:700}
.mle-ico{all:unset;cursor:pointer;width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;border-radius:5px;color:#a9a9b5;flex:none}
.mle-ico:hover{background:#3a3a46;color:#fff}
.mle-ico.del:hover{background:#5a2330;color:#ffd1da}
.mle-ico svg{width:14px;height:14px}
.mle-field{margin-bottom:10px}
.mle-field>label{display:block;color:#a8a8b4;font-size:12px;margin-bottom:4px}
.mle-field>label small{color:#76767f}
.mle-seg{display:flex;background:#101014;border:1px solid #33333d;border-radius:7px;padding:2px;gap:2px}
.mle-seg button{all:unset;cursor:pointer;flex:1;text-align:center;padding:5px 0;border-radius:5px;color:#b9b9c4;font-size:12.5px}
.mle-seg button.on{background:#ff8fd1;color:#1d1220;font-weight:700}
.mle-pos{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.mle-pos label{font-size:11px;color:#8d8d99;display:flex;flex-direction:column;gap:3px}
.mle-pos input{width:100% !important}
.mle-acts{display:flex;flex-wrap:wrap;gap:6px}
.mle-issue{background:#3a2f17;color:#ffdc8f;border-radius:6px;padding:6px 8px;font-size:12px;margin-bottom:10px}
.mle-json{white-space:pre-wrap;word-break:break-all;background:#0f0f13;border:1px solid #2c2c35;border-radius:6px;padding:8px;font:11.5px/1.45 ui-monospace,Consolas,monospace;color:#cfe8d0;max-height:220px;overflow:auto;margin:8px 0}
.mle-foot{padding:7px 14px;border-top:1px solid #2a2a33;background:#1c1c22;color:#9898a4;font-size:12px;display:flex;flex-wrap:wrap;gap:4px 16px}
.mle-foot b{color:#e1e1e8;font-weight:600}
.mle-empty{color:#8d8d99;font-size:12.5px;padding:4px 0}
@media (max-width:860px){.mle-body{flex-direction:column}.mle-side{width:auto;border-left:none;border-top:1px solid #2a2a33;height:45%}}
`;

function injectCSS() {
  if (document.getElementById("mle-style")) return;
  const s = document.createElement("style");
  s.id = "mle-style";
  s.textContent = CSS;
  document.head.appendChild(s);
}

const ICONS = {
  eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  eyeOff: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6C3.8 8.4 2 12 2 12s3.5 7 10 7a9.8 9.8 0 0 0 5.4-1.6"/></svg>',
  up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 15l6-6 6 6"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M10 11v6M14 11v6M5 7l1 13h12l1-13M9 7V4h6v3"/></svg>',
};

// ───────────────────────── node preview ─────────────────────────

function drawPreview(node) {
  const pv = node.__mlePreview;
  if (!pv) return;
  const { canvas, info, wrap } = pv;
  const [W, H] = getDims(node);
  const state = parseState(getWidget(node, "layout_data")?.value);

  const rect = wrap.getBoundingClientRect();
  const cw = Math.max(1, Math.round(rect.width)), ch = Math.max(1, Math.round(rect.height));
  const dpr = window.devicePixelRatio || 1;
  if (canvas.width !== cw * dpr || canvas.height !== ch * dpr) {
    canvas.width = cw * dpr;
    canvas.height = ch * dpr;
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cw, ch);

  const scale = Math.min(cw / W, ch / H);
  const iw = W * scale, ih = H * scale, ox = (cw - iw) / 2, oy = (ch - ih) / 2;
  ctx.fillStyle = "#121216";
  ctx.fillRect(ox, oy, iw, ih);
  ctx.strokeStyle = "#3a3a46";
  ctx.lineWidth = 1;
  ctx.strokeRect(ox + 0.5, oy + 0.5, iw - 1, ih - 1);

  state.boxes.forEach((b, i) => {
    const x = ox + b.x0 * iw, y = oy + b.y0 * ih, w = (b.x1 - b.x0) * iw, h = (b.y1 - b.y0) * ih;
    ctx.globalAlpha = b.enabled ? 1 : 0.35;
    ctx.fillStyle = boxColor(b.id, 0.16);
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = boxColor(b.id, 0.95);
    ctx.setLineDash(b.enabled ? [] : [4, 3]);
    ctx.strokeRect(x + 0.5, y + 0.5, Math.max(0, w - 1), Math.max(0, h - 1));
    ctx.setLineDash([]);
    if (w > 18 && h > 12) {
      ctx.font = "600 10px system-ui, sans-serif";
      ctx.fillStyle = boxColor(b.id, 1, 78);
      const label = `${i + 1} ${boxTitle(b)}`;
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.clip();
      ctx.fillText(label, x + 3, y + 11);
      ctx.restore();
    }
  });
  ctx.globalAlpha = 1;

  const on = state.boxes.filter((b) => b.enabled).length;
  const off = state.boxes.length - on;
  const issues = state.boxes.filter((b) => b.enabled && boxIssue(b)).length;
  const mp = (W * H) / 1e6;
  let html = `<b>${state.boxes.length}</b> box${state.boxes.length === 1 ? "" : "es"}${off ? ` (${off} hidden)` : ""} · <b>${W}×${H}</b> · ${mp.toFixed(2)} MP`;
  if (issues) html += `<br><span class="mle-pv-warn">⚠ ${issues} box${issues === 1 ? " needs" : "es need"} a description</span>`;
  else if (mp < 0.9) html += `<br><span class="mle-pv-warn">Below MOSS's recommended ~1 MP</span>`;
  info.innerHTML = html;
}

function schedulePreview(node) {
  if (node.__mleRaf) return;
  node.__mleRaf = requestAnimationFrame(() => {
    node.__mleRaf = 0;
    drawPreview(node);
  });
}

// ───────────────────────── the editor ─────────────────────────

class LayoutEditor {
  constructor(node) {
    this.node = node;
    this.state = parseState(getWidget(node, "layout_data")?.value);
    this.summary = String(getWidget(node, "summary")?.value ?? "");
    this.sel = null; // selected box id
    this.hover = null;
    this.drag = null;
    this.undo = [];
    this.redo = [];
    this.pending = null;
    this.snap = localStorage.getItem("mle.snap") === "1";
    this.grid = localStorage.getItem("mle.grid") !== "0";
    this.build();
  }

  // ── setup ──
  build() {
    injectCSS();
    const [W, H] = getDims(this.node);
    const ov = (this.root = document.createElement("div"));
    ov.className = "mle-overlay";
    ov.innerHTML = `
      <div class="mle-win" role="dialog" aria-label="MOSS Layout Editor">
        <div class="mle-head">
          <div class="mle-title">MOSS <span>Layout Editor</span></div>
          <div class="mle-grp">
            <label>Width</label><input type="number" data-k="w" min="256" max="4096" step="16" value="${W}">
            <label>Height</label><input type="number" data-k="h" min="256" max="4096" step="16" value="${H}">
            <select data-k="preset" title="Size presets (~1 MP)">
              <option value="">Presets…</option>
              ${PRESETS.map(([n, w, h]) => `<option value="${w}x${h}">${n} — ${w}×${h}</option>`).join("")}
            </select>
          </div>
          <label class="mle-chk"><input type="checkbox" data-k="snap" ${this.snap ? "checked" : ""}> Snap to 16px</label>
          <label class="mle-chk"><input type="checkbox" data-k="grid" ${this.grid ? "checked" : ""}> Grid</label>
          <div class="mle-sp"></div>
          <button class="mle-btn" data-k="undo" title="Undo (Ctrl+Z)">↶ Undo</button>
          <button class="mle-btn" data-k="redo" title="Redo (Ctrl+Y)">↷ Redo</button>
          <button class="mle-btn danger" data-k="clear" title="Delete every box">Clear all</button>
          <button class="mle-btn primary" data-k="done" title="Close (Esc). Changes are saved as you go.">Done</button>
        </div>
        <div class="mle-body">
          <div class="mle-stage"><canvas></canvas><div class="mle-dims"></div></div>
          <div class="mle-side">
            <div class="mle-sec">
              <h4>Whole image</h4>
              <textarea data-k="summary" rows="3" placeholder="Describe the whole image, e.g. a cosy pink gaming room at night"></textarea>
            </div>
            <div class="mle-sec">
              <h4>Boxes <span class="mle-count"></span></h4>
              <div class="mle-list"></div>
            </div>
            <div class="mle-sec mle-props"></div>
            <div class="mle-sec">
              <h4>Output</h4>
              <div class="mle-acts"><button class="mle-btn" data-k="copy">Copy JSON</button><button class="mle-btn" data-k="togglejson">Show JSON</button></div>
              <pre class="mle-json" style="display:none"></pre>
            </div>
          </div>
        </div>
        <div class="mle-foot">
          <span><b>Drag empty space</b> new box</span>
          <span><b>Click a box again</b> pick the one under it</span>
          <span><b>Drag edges / corners</b> resize</span>
          <span><b>Delete</b> remove</span>
          <span><b>Arrows</b> nudge (Shift = 16px)</span>
          <span><b>Ctrl+D</b> duplicate</span>
          <span><b>Ctrl+Z / Ctrl+Y</b> undo / redo</span>
        </div>
      </div>`;

    const q = (k) => ov.querySelector(`[data-k="${k}"]`);
    this.el = {
      canvas: ov.querySelector("canvas"),
      stage: ov.querySelector(".mle-stage"),
      dims: ov.querySelector(".mle-dims"),
      list: ov.querySelector(".mle-list"),
      count: ov.querySelector(".mle-count"),
      props: ov.querySelector(".mle-props"),
      json: ov.querySelector(".mle-json"),
      w: q("w"), h: q("h"), preset: q("preset"), summary: q("summary"),
      undo: q("undo"), redo: q("redo"),
    };
    this.el.summary.value = this.summary;

    // header
    const applySize = () => {
      const fit = (v) => Math.min(4096, Math.max(256, snap16(v)));
      const w = fit(this.el.w.value), h = fit(this.el.h.value);
      this.el.w.value = w;
      this.el.h.value = h;
      setWidgetValue(this.node, "width", w);
      setWidgetValue(this.node, "height", h);
      this.el.preset.value = "";
      this.layout();
      this.commit();
    };
    this.el.w.addEventListener("change", applySize);
    this.el.h.addEventListener("change", applySize);
    this.el.preset.addEventListener("change", () => {
      if (!this.el.preset.value) return;
      const [w, h] = this.el.preset.value.split("x");
      this.el.w.value = w;
      this.el.h.value = h;
      applySize();
    });
    q("snap").addEventListener("change", (e) => {
      this.snap = e.target.checked;
      localStorage.setItem("mle.snap", this.snap ? "1" : "0");
    });
    q("grid").addEventListener("change", (e) => {
      this.grid = e.target.checked;
      localStorage.setItem("mle.grid", this.grid ? "1" : "0");
      this.draw();
    });
    this.el.undo.addEventListener("click", () => this.doUndo());
    this.el.redo.addEventListener("click", () => this.doRedo());
    q("clear").addEventListener("click", () => {
      if (!this.state.boxes.length) return;
      if (!confirm(`Delete all ${this.state.boxes.length} boxes?`)) return;
      this.begin();
      this.state.boxes = [];
      this.sel = null;
      this.end();
      this.refresh();
    });
    q("done").addEventListener("click", () => this.close());
    q("copy").addEventListener("click", async (e) => {
      const [W2, H2] = getDims(this.node);
      const out = buildLayout(this.state, this.summary, W2, H2).text;
      try {
        await navigator.clipboard.writeText(out);
        e.target.textContent = "Copied ✓";
      } catch (_) {
        e.target.textContent = "Copy failed";
      }
      setTimeout(() => (e.target.textContent = "Copy JSON"), 1400);
    });
    q("togglejson").addEventListener("click", (e) => {
      const show = this.el.json.style.display === "none";
      this.el.json.style.display = show ? "block" : "none";
      e.target.textContent = show ? "Hide JSON" : "Show JSON";
    });

    // summary
    this.el.summary.addEventListener("focus", () => this.begin());
    this.el.summary.addEventListener("blur", () => this.end());
    this.el.summary.addEventListener("input", () => {
      this.summary = this.el.summary.value;
      this.commit();
    });

    // canvas
    const c = this.el.canvas;
    this.onDown = this.onDown.bind(this);
    this.onMove = this.onMove.bind(this);
    this.onUp = this.onUp.bind(this);
    c.addEventListener("pointerdown", this.onDown);
    c.addEventListener("pointermove", this.onMove);
    c.addEventListener("pointerup", this.onUp);
    c.addEventListener("pointercancel", this.onUp);
    c.addEventListener("pointerleave", () => {
      if (!this.drag && this.hover != null) {
        this.hover = null;
        this.draw();
      }
    });
    c.addEventListener("dblclick", (e) => {
      const hit = this.hits(this.pos(e))[0];
      if (hit) this.focusField("caption");
    });

    // Keys. ComfyUI has its own window-level shortcuts (Ctrl+Z = undo the whole
    // workflow, Delete = delete nodes) that we can't always stop. They all skip
    // events aimed at text inputs, so while the editor is open keyboard focus
    // always sits in an input: a real field, or this invisible "sink".
    const sink = (this.sink = document.createElement("input"));
    sink.type = "text";
    sink.tabIndex = -1;
    sink.setAttribute("aria-hidden", "true");
    sink.style.cssText = "position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;pointer-events:none";
    sink.addEventListener("input", () => (sink.value = ""));
    ov.appendChild(sink);
    ov.addEventListener("focusout", () =>
      setTimeout(() => {
        const a = document.activeElement;
        if (this.root.isConnected && (!a || a === document.body || !this.root.contains(a))) this.focusSink();
      }, 0)
    );
    ov.addEventListener("pointerdown", (e) => {
      if (!e.target.closest("input,textarea,select")) setTimeout(() => this.focusSink(), 0);
    });

    this.onKey = this.onKey.bind(this);
    window.addEventListener("keydown", this.onKey, true);
    for (const t of ["keyup", "keypress"]) ov.addEventListener(t, (e) => e.stopPropagation());
    ov.addEventListener("wheel", (e) => e.stopPropagation(), { passive: true });
    ov.addEventListener("contextmenu", (e) => e.stopPropagation());

    this.ro = new ResizeObserver(() => this.layout());
    this.ro.observe(this.el.stage);
  }

  open() {
    document.body.appendChild(this.root);
    this.layout();
    this.refresh();
    this.focusSink();
  }

  focusSink() {
    if (this.root.isConnected) this.sink?.focus({ preventScroll: true });
  }

  close() {
    this.end();
    window.removeEventListener("keydown", this.onKey, true);
    this.ro?.disconnect();
    this.root.remove();
    this.node.__mleEditor = null;
    schedulePreview(this.node);
    markChanged(this.node);
  }

  // ── persistence / undo ──
  snapshot() {
    return JSON.stringify({ s: this.state, m: this.summary });
  }

  begin() {
    if (this.pending == null) this.pending = this.snapshot();
  }

  end() {
    if (this.pending == null) return;
    const before = this.pending;
    this.pending = null;
    if (before !== this.snapshot()) {
      this.undo.push(before);
      if (this.undo.length > UNDO_LIMIT) this.undo.shift();
      this.redo = [];
    }
    this.updateUndo();
  }

  restore(snap) {
    const { s, m } = JSON.parse(snap);
    this.state = parseState(JSON.stringify(s));
    this.summary = m;
    this.el.summary.value = m;
    if (!this.state.boxes.some((b) => b.id === this.sel)) this.sel = null;
    this.commit();
    this.refresh();
  }

  doUndo() {
    this.end();
    if (!this.undo.length) return;
    this.redo.push(this.snapshot());
    this.restore(this.undo.pop());
    this.updateUndo();
  }

  doRedo() {
    this.end();
    if (!this.redo.length) return;
    this.undo.push(this.snapshot());
    this.restore(this.redo.pop());
    this.updateUndo();
  }

  updateUndo() {
    this.el.undo.disabled = !this.undo.length;
    this.el.redo.disabled = !this.redo.length;
  }

  /** Write state to the node (saved with the workflow). */
  commit() {
    const data = JSON.stringify(this.state);
    const w = getWidget(this.node, "layout_data");
    if (w) w.value = data;
    const sw = getWidget(this.node, "summary");
    if (sw && sw.value !== this.summary) {
      sw.value = this.summary;
      if (sw.inputEl && sw.inputEl.value !== this.summary) sw.inputEl.value = this.summary;
    }
    this.updateJSON();
    schedulePreview(this.node);
    markChanged(this.node);
  }

  updateJSON() {
    const [W, H] = getDims(this.node);
    const out = buildLayout(this.state, this.summary, W, H);
    let txt = out.text;
    if (out.count) {
      try {
        txt = JSON.stringify(JSON.parse(out.text), null, 1);
      } catch (_) {
        /* keep raw */
      }
    }
    this.el.json.textContent = out.count ? txt : `(no boxes to send — the prompt will be just the "Whole image" text)\n\n${txt}`;
  }

  // ── geometry ──
  layout() {
    const [W, H] = getDims(this.node);
    this.W = W;
    this.H = H;
    const r = this.el.stage.getBoundingClientRect();
    const availW = Math.max(50, r.width - 36), availH = Math.max(50, r.height - 36);
    const scale = Math.min(availW / W, availH / H);
    const cw = Math.max(1, Math.floor(W * scale)), ch = Math.max(1, Math.floor(H * scale));
    const dpr = window.devicePixelRatio || 1;
    const c = this.el.canvas;
    c.style.width = cw + "px";
    c.style.height = ch + "px";
    c.width = Math.round(cw * dpr);
    c.height = Math.round(ch * dpr);
    this.cw = cw;
    this.ch = ch;
    this.dpr = dpr;
    this.draw();
  }

  pos(e) {
    const r = this.el.canvas.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    return { x: clamp01(x), y: clamp01(y), rx: x, ry: y };
  }

  snapX(v) {
    return this.snap ? clamp01(Math.round((v * this.W) / 16) * 16 / this.W) : v;
  }

  snapY(v) {
    return this.snap ? clamp01(Math.round((v * this.H) / 16) * 16 / this.H) : v;
  }

  getBox(id) {
    return this.state.boxes.find((b) => b.id === id);
  }

  /** Boxes under a point, topmost first. */
  hits(p) {
    return this.state.boxes
      .filter((b) => p.rx >= b.x0 && p.rx <= b.x1 && p.ry >= b.y0 && p.ry <= b.y1)
      .reverse();
  }

  handleAt(b, p) {
    if (!b) return null;
    const px = p.rx * this.cw, py = p.ry * this.ch;
    const x0 = b.x0 * this.cw, x1 = b.x1 * this.cw, y0 = b.y0 * this.ch, y1 = b.y1 * this.ch;
    const near = (a, c) => Math.abs(a - c) <= HANDLE;
    const inX = px >= x0 - HANDLE && px <= x1 + HANDLE;
    const inY = py >= y0 - HANDLE && py <= y1 + HANDLE;
    let v = "", h = "";
    if (inX && near(py, y0)) v = "n";
    else if (inX && near(py, y1)) v = "s";
    if (inY && near(px, x0)) h = "w";
    else if (inY && near(px, x1)) h = "e";
    return v + h || null;
  }

  cursorFor(handle) {
    return { n: "ns-resize", s: "ns-resize", e: "ew-resize", w: "ew-resize", nw: "nwse-resize", se: "nwse-resize", ne: "nesw-resize", sw: "nesw-resize" }[handle];
  }

  // ── pointer ──
  onDown(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    this.focusSink(); // leaves any text field (saving its edit) and keeps keys away from ComfyUI
    const p = this.pos(e);
    this.el.canvas.setPointerCapture(e.pointerId);
    const sel = this.getBox(this.sel);
    const handle = this.handleAt(sel, p);
    this.begin();

    if (sel && handle) {
      this.drag = { mode: "resize", handle, id: sel.id, start: { ...sel }, p0: p, moved: false };
    } else if (sel && p.rx >= sel.x0 && p.rx <= sel.x1 && p.ry >= sel.y0 && p.ry <= sel.y1) {
      // Clicking inside the selected box keeps it selected even if others are on top.
      this.drag = { mode: "move", id: sel.id, start: { ...sel }, p0: p, moved: false, cycle: true };
    } else {
      const top = this.hits(p)[0];
      if (top) {
        this.sel = top.id;
        this.drag = { mode: "move", id: top.id, start: { ...top }, p0: p, moved: false, cycle: false };
        this.refresh();
      } else {
        this.drag = { mode: "draw", p0: p, p1: p, moved: false };
        if (this.sel != null) {
          this.sel = null;
          this.refresh();
        }
      }
    }
    this.draw();
  }

  onMove(e) {
    const p = this.pos(e);
    const d = this.drag;
    if (!d) {
      const sel = this.getBox(this.sel);
      const handle = this.handleAt(sel, p);
      const inSel = sel && p.rx >= sel.x0 && p.rx <= sel.x1 && p.ry >= sel.y0 && p.ry <= sel.y1;
      const hover = inSel ? sel.id : this.hits(p)[0]?.id ?? null;
      this.el.canvas.style.cursor = handle ? this.cursorFor(handle) : hover != null ? "move" : "crosshair";
      if (hover !== this.hover) {
        this.hover = hover;
        this.draw();
      }
      return;
    }
    const dist = Math.hypot((p.rx - d.p0.rx) * this.cw, (p.ry - d.p0.ry) * this.ch);
    if (!d.moved && dist < 3) return;
    d.moved = true;
    const minX = MIN_PX / this.W, minY = MIN_PX / this.H;

    if (d.mode === "draw") {
      d.p1 = p;
    } else if (d.mode === "move") {
      const b = this.getBox(d.id), s = d.start;
      const w = s.x1 - s.x0, h = s.y1 - s.y0;
      let x0 = this.snapX(s.x0 + (p.rx - d.p0.rx)), y0 = this.snapY(s.y0 + (p.ry - d.p0.ry));
      x0 = Math.min(Math.max(0, x0), 1 - w);
      y0 = Math.min(Math.max(0, y0), 1 - h);
      Object.assign(b, { x0, y0, x1: x0 + w, y1: y0 + h });
    } else if (d.mode === "resize") {
      const b = this.getBox(d.id), s = d.start, hd = d.handle;
      let { x0, y0, x1, y1 } = s;
      if (hd.includes("w")) x0 = Math.min(this.snapX(p.x), x1 - minX);
      if (hd.includes("e")) x1 = Math.max(this.snapX(p.x), x0 + minX);
      if (hd.includes("n")) y0 = Math.min(this.snapY(p.y), y1 - minY);
      if (hd.includes("s")) y1 = Math.max(this.snapY(p.y), y0 + minY);
      Object.assign(b, { x0: clamp01(x0), y0: clamp01(y0), x1: clamp01(x1), y1: clamp01(y1) });
    }
    this.draw();
    if (d.mode !== "draw") this.refreshProps(true);
  }

  onUp(e) {
    const d = this.drag;
    if (!d) return;
    this.drag = null;
    try {
      this.el.canvas.releasePointerCapture(e.pointerId);
    } catch (_) {
      /* already released */
    }
    const p = this.pos(e);

    if (d.mode === "draw" && d.moved) {
      const x0 = this.snapX(Math.min(d.p0.x, d.p1.x)), x1 = this.snapX(Math.max(d.p0.x, d.p1.x));
      const y0 = this.snapY(Math.min(d.p0.y, d.p1.y)), y1 = this.snapY(Math.max(d.p0.y, d.p1.y));
      if ((x1 - x0) * this.W >= MIN_PX && (y1 - y0) * this.H >= MIN_PX) {
        const id = this.state.nextId++;
        this.state.boxes.push({ id, name: "", label: "object", caption: "", text: "", enabled: true, x0, y0, x1, y1 });
        this.sel = id;
        this.end();
        this.commit();
        this.refresh();
        this.focusField("caption");
        return;
      }
    } else if (d.mode === "move" && !d.moved && d.cycle) {
      // Plain click on the already-selected box: step to the box underneath it.
      const stack = this.hits(p);
      if (stack.length > 1) {
        const i = stack.findIndex((b) => b.id === this.sel);
        this.sel = stack[(i + 1) % stack.length].id;
        this.refresh();
      }
    }
    this.end();
    if (d.moved) this.commit();
    this.refresh();
  }

  // ── keyboard ──
  onKey(e) {
    if (!this.root.isConnected) return;
    const t = e.target;
    const typing =
      t && t !== this.sink && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable);
    const mod = e.ctrlKey || e.metaKey;
    const k = e.key;

    // Never let ComfyUI react to keys while the editor is open.
    e.stopPropagation();

    if (k === "Escape") {
      e.preventDefault();
      if (typing && this.root.contains(t)) t.blur();
      else this.close();
      return;
    }
    if (typing) {
      // Let fields handle their own keys; still allow Ctrl+Enter to leave a field.
      if (mod && k === "Enter") t.blur();
      return;
    }
    if (mod && (k === "z" || k === "Z")) {
      e.preventDefault();
      e.shiftKey ? this.doRedo() : this.doUndo();
      return;
    }
    if (mod && (k === "y" || k === "Y")) {
      e.preventDefault();
      this.doRedo();
      return;
    }
    const sel = this.getBox(this.sel);
    if (mod && (k === "d" || k === "D")) {
      e.preventDefault();
      if (sel) this.duplicate(sel.id);
      return;
    }
    if ((k === "Delete" || k === "Backspace") && sel) {
      e.preventDefault();
      this.remove(sel.id);
      return;
    }
    if (k === "Tab" && this.state.boxes.length) {
      e.preventDefault();
      const ids = this.state.boxes.map((b) => b.id);
      const i = ids.indexOf(this.sel);
      this.sel = ids[(i + (e.shiftKey ? -1 : 1) + ids.length) % ids.length];
      this.refresh();
      return;
    }
    if (sel && k.startsWith("Arrow")) {
      e.preventDefault();
      const step = e.shiftKey ? 16 : 1;
      const dx = k === "ArrowLeft" ? -step : k === "ArrowRight" ? step : 0;
      const dy = k === "ArrowUp" ? -step : k === "ArrowDown" ? step : 0;
      this.begin();
      const w = sel.x1 - sel.x0, h = sel.y1 - sel.y0;
      const x0 = Math.min(Math.max(0, sel.x0 + dx / this.W), 1 - w);
      const y0 = Math.min(Math.max(0, sel.y0 + dy / this.H), 1 - h);
      Object.assign(sel, { x0, y0, x1: x0 + w, y1: y0 + h });
      clearTimeout(this.nudgeT);
      this.nudgeT = setTimeout(() => this.end(), 600);
      this.commit();
      this.refresh();
    }
  }

  // ── box actions ──
  remove(id) {
    this.end();
    this.begin();
    const i = this.state.boxes.findIndex((b) => b.id === id);
    if (i < 0) return;
    this.state.boxes.splice(i, 1);
    if (this.sel === id) {
      const next = this.state.boxes[Math.min(i, this.state.boxes.length - 1)];
      this.sel = next ? next.id : null;
    }
    this.end();
    this.commit();
    this.refresh();
  }

  duplicate(id) {
    const b = this.getBox(id);
    if (!b) return;
    this.end();
    this.begin();
    const off = 16;
    const w = b.x1 - b.x0, h = b.y1 - b.y0;
    const x0 = Math.min(b.x0 + off / this.W, 1 - w), y0 = Math.min(b.y0 + off / this.H, 1 - h);
    const copy = { ...b, id: this.state.nextId++, x0, y0, x1: x0 + w, y1: y0 + h, name: b.name ? `${b.name} copy` : "" };
    this.state.boxes.splice(this.state.boxes.indexOf(b) + 1, 0, copy);
    this.sel = copy.id;
    this.end();
    this.commit();
    this.refresh();
  }

  reorder(id, where) {
    const arr = this.state.boxes;
    const i = arr.findIndex((b) => b.id === id);
    if (i < 0) return;
    const j = where === "up" ? i + 1 : where === "down" ? i - 1 : where === "front" ? arr.length - 1 : 0;
    if (j < 0 || j >= arr.length || j === i) return;
    this.end();
    this.begin();
    const [b] = arr.splice(i, 1);
    arr.splice(j, 0, b);
    this.end();
    this.commit();
    this.refresh();
  }

  toggle(id) {
    const b = this.getBox(id);
    if (!b) return;
    this.end();
    this.begin();
    b.enabled = !b.enabled;
    this.end();
    this.commit();
    this.refresh();
  }

  update(id, patch) {
    const b = this.getBox(id);
    if (!b) return;
    Object.assign(b, patch);
    this.commit();
    this.draw();
    this.refreshList();
  }

  focusField(name) {
    setTimeout(() => {
      const f = this.el.props.querySelector(`[data-f="${name}"]`);
      if (f) {
        f.focus();
        f.select?.();
      }
    }, 0);
  }

  // ── rendering ──
  refresh() {
    this.draw();
    this.refreshList();
    this.refreshProps();
    this.updateJSON();
    this.updateUndo();
    const a = document.activeElement;
    if (!a || a === document.body || !this.root.contains(a)) this.focusSink();
  }

  refreshList() {
    const boxes = this.state.boxes;
    this.el.count.textContent = boxes.length ? `${boxes.length}` : "";
    if (!boxes.length) {
      this.el.list.innerHTML = `<div class="mle-empty">No boxes yet. Drag on the image to draw one.</div>`;
      return;
    }
    // Top of the list = front-most box.
    const rows = boxes
      .map((b, i) => ({ b, n: i + 1 }))
      .reverse()
      .map(({ b, n }) => {
        const title = boxTitle(b);
        const issue = b.enabled ? boxIssue(b) : "";
        return `<div class="mle-row${b.id === this.sel ? " sel" : ""}${b.enabled ? "" : " off"}" data-id="${b.id}">
          <span class="mle-num" style="background:${boxColor(b.id, 1)}">${n}</span>
          <span class="mle-row-title">${title ? esc(title) : "<i>no description</i>"}</span>
          ${issue ? `<span class="mle-warn" title="${esc(issue)}">!</span>` : ""}
          <span class="mle-chip">${esc(b.label)}</span>
          <button class="mle-ico" data-a="toggle" title="${b.enabled ? "Hide (won't be sent)" : "Show"}">${b.enabled ? ICONS.eye : ICONS.eyeOff}</button>
          <button class="mle-ico" data-a="up" title="Bring forward">${ICONS.up}</button>
          <button class="mle-ico" data-a="down" title="Send backward">${ICONS.down}</button>
          <button class="mle-ico del" data-a="del" title="Delete">${ICONS.trash}</button>
        </div>`;
      });
    this.el.list.innerHTML = rows.join("");
    this.el.list.querySelectorAll(".mle-row").forEach((row) => {
      const id = Number(row.dataset.id);
      row.addEventListener("click", (e) => {
        const a = e.target.closest("[data-a]")?.dataset.a;
        if (a === "toggle") this.toggle(id);
        else if (a === "up") this.reorder(id, "up");
        else if (a === "down") this.reorder(id, "down");
        else if (a === "del") this.remove(id);
        else {
          this.sel = id;
          this.refresh();
        }
      });
    });
  }

  refreshProps(positionOnly = false) {
    const b = this.getBox(this.sel);
    const P = this.el.props;
    const px = (b) => ({
      x: Math.round(b.x0 * this.W),
      y: Math.round(b.y0 * this.H),
      w: Math.round((b.x1 - b.x0) * this.W),
      h: Math.round((b.y1 - b.y0) * this.H),
    });
    if (positionOnly) {
      if (!b) return;
      const v = px(b);
      for (const k of ["x", "y", "w", "h"]) {
        const inp = P.querySelector(`[data-p="${k}"]`);
        if (inp && document.activeElement !== inp) inp.value = v[k];
      }
      return;
    }
    if (!b) {
      P.innerHTML = `<h4>Selected box</h4><div class="mle-empty">Draw a box on the image, or click one to edit it.<br>Boxes hidden under others: click the top box again, or pick them in the list.</div>`;
      return;
    }
    const n = this.state.boxes.indexOf(b) + 1;
    const v = px(b);
    const issue = boxIssue(b);
    P.innerHTML = `
      <h4><span class="mle-num" style="background:${boxColor(b.id, 1)}">${n}</span> Selected box</h4>
      ${issue ? `<div class="mle-issue">⚠ ${esc(issue)}</div>` : ""}
      <div class="mle-field"><label>Name <small>— just for you, not sent to the model</small></label>
        <input type="text" data-f="name" placeholder="e.g. Chair" value="${esc(b.name)}" style="width:100%"></div>
      <div class="mle-field"><label>Type</label>
        <div class="mle-seg">${LABELS.map(([k, t]) => `<button data-label="${k}" class="${b.label === k ? "on" : ""}">${t}</button>`).join("")}</div></div>
      <div class="mle-field"><label>Description <small>— what it looks like</small></label>
        <textarea data-f="caption" rows="3" placeholder="e.g. white and pink gaming chair with cat-ear headrest">${esc(b.caption)}</textarea></div>
      ${b.label === "text" ? `<div class="mle-field"><label>Text to draw <small>— exact words shown in the image</small></label>
        <textarea data-f="text" rows="2" placeholder="e.g. GAME ON">${esc(b.text)}</textarea></div>` : ""}
      <div class="mle-field"><label>Position <small>— pixels from top-left</small></label>
        <div class="mle-pos">
          <label>X<input type="number" data-p="x" value="${v.x}"></label>
          <label>Y<input type="number" data-p="y" value="${v.y}"></label>
          <label>Width<input type="number" data-p="w" value="${v.w}"></label>
          <label>Height<input type="number" data-p="h" value="${v.h}"></label>
        </div></div>
      <div class="mle-acts">
        <button class="mle-btn" data-b="dup" title="Ctrl+D">Duplicate</button>
        <button class="mle-btn" data-b="front">Bring to front</button>
        <button class="mle-btn" data-b="back">Send to back</button>
        <button class="mle-btn" data-b="toggle">${b.enabled ? "Hide" : "Show"}</button>
        <button class="mle-btn danger" data-b="del" title="Delete key">Delete</button>
      </div>`;

    P.querySelectorAll("[data-f]").forEach((f) => {
      f.addEventListener("focus", () => this.begin());
      f.addEventListener("blur", () => {
        this.end();
        this.refreshList();
      });
      f.addEventListener("input", () => {
        this.update(b.id, { [f.dataset.f]: f.value });
        const iss = boxIssue(b);
        const box = P.querySelector(".mle-issue");
        if (!iss && box) box.remove();
      });
    });
    P.querySelectorAll("[data-label]").forEach((btn) =>
      btn.addEventListener("click", () => {
        this.end();
        this.begin();
        b.label = btn.dataset.label;
        this.end();
        this.commit();
        this.refresh();
        if (b.label === "text") this.focusField("text");
      })
    );
    P.querySelectorAll("[data-p]").forEach((inp) =>
      inp.addEventListener("change", () => {
        const g = (k) => Number(P.querySelector(`[data-p="${k}"]`).value) || 0;
        let w = Math.min(this.W, Math.max(MIN_PX, g("w"))), h = Math.min(this.H, Math.max(MIN_PX, g("h")));
        let x = Math.min(this.W - w, Math.max(0, g("x"))), y = Math.min(this.H - h, Math.max(0, g("y")));
        this.end();
        this.begin();
        Object.assign(b, { x0: x / this.W, y0: y / this.H, x1: (x + w) / this.W, y1: (y + h) / this.H });
        this.end();
        this.commit();
        this.draw();
        this.refreshProps(true);
      })
    );
    const act = (k, fn) => P.querySelector(`[data-b="${k}"]`).addEventListener("click", fn);
    act("dup", () => this.duplicate(b.id));
    act("front", () => this.reorder(b.id, "front"));
    act("back", () => this.reorder(b.id, "back"));
    act("toggle", () => this.toggle(b.id));
    act("del", () => this.remove(b.id));
  }

  draw() {
    const c = this.el.canvas;
    if (!this.cw) return;
    const ctx = c.getContext("2d");
    const { cw, ch, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cw, ch);
    ctx.fillStyle = "#1a1a20";
    ctx.fillRect(0, 0, cw, ch);

    if (this.grid) {
      ctx.strokeStyle = "rgba(255,255,255,0.05)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 1; i < 8; i++) {
        const x = Math.round((cw * i) / 8) + 0.5, y = Math.round((ch * i) / 8) + 0.5;
        ctx.moveTo(x, 0); ctx.lineTo(x, ch);
        ctx.moveTo(0, y); ctx.lineTo(cw, y);
      }
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,143,209,0.16)";
      ctx.beginPath();
      ctx.moveTo(Math.round(cw / 2) + 0.5, 0); ctx.lineTo(Math.round(cw / 2) + 0.5, ch);
      ctx.moveTo(0, Math.round(ch / 2) + 0.5); ctx.lineTo(cw, Math.round(ch / 2) + 0.5);
      ctx.stroke();
    }

    const rectOf = (b) => [b.x0 * cw, b.y0 * ch, (b.x1 - b.x0) * cw, (b.y1 - b.y0) * ch];

    this.state.boxes.forEach((b, i) => {
      const [x, y, w, h] = rectOf(b);
      const isSel = b.id === this.sel, isHover = b.id === this.hover;
      ctx.globalAlpha = b.enabled ? 1 : 0.4;
      ctx.fillStyle = boxColor(b.id, isSel ? 0.26 : 0.14);
      ctx.fillRect(x, y, w, h);
      ctx.lineWidth = isHover && !isSel ? 2 : 1.5;
      ctx.strokeStyle = boxColor(b.id, 0.95);
      ctx.setLineDash(b.enabled ? [] : [6, 4]);
      ctx.strokeRect(x + 0.75, y + 0.75, Math.max(0, w - 1.5), Math.max(0, h - 1.5));
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    });

    // tags in a second pass so no box hides another box's name
    this.state.boxes.forEach((b, i) => {
      const [x, y, w, h] = rectOf(b);
      ctx.globalAlpha = b.enabled ? 1 : 0.45;
      const title = boxTitle(b);
      const label = `${i + 1}${title ? "  " + title : ""}${b.label !== "object" ? `  [${b.label}]` : ""}`;
      ctx.font = "600 12px system-ui, sans-serif";
      const tw = Math.min(ctx.measureText(label).width + 10, Math.max(22, w));
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, y, Math.max(22, w), Math.max(18, h));
      ctx.clip();
      ctx.fillStyle = boxColor(b.id, 0.95, 72);
      ctx.fillRect(x, y, tw, 18);
      ctx.fillStyle = "#101014";
      ctx.fillText(label, x + 5, y + 13);
      ctx.restore();
      ctx.globalAlpha = 1;
    });

    // selected outline + handles on top of everything
    const sel = this.getBox(this.sel);
    if (sel) {
      const [x, y, w, h] = rectOf(sel);
      ctx.lineWidth = 2;
      ctx.strokeStyle = "#ffffff";
      ctx.strokeRect(x + 1, y + 1, Math.max(0, w - 2), Math.max(0, h - 2));
      const pts = [[x, y], [x + w / 2, y], [x + w, y], [x + w, y + h / 2], [x + w, y + h], [x + w / 2, y + h], [x, y + h], [x, y + h / 2]];
      for (const [hx, hy] of pts) {
        ctx.fillStyle = "#ffffff";
        ctx.strokeStyle = "#16161b";
        ctx.lineWidth = 1.5;
        ctx.fillRect(hx - 4.5, hy - 4.5, 9, 9);
        ctx.strokeRect(hx - 4.5, hy - 4.5, 9, 9);
      }
    }

    // box being drawn
    const d = this.drag;
    if (d?.mode === "draw" && d.moved) {
      const x0 = Math.min(d.p0.x, d.p1.x) * cw, x1 = Math.max(d.p0.x, d.p1.x) * cw;
      const y0 = Math.min(d.p0.y, d.p1.y) * ch, y1 = Math.max(d.p0.y, d.p1.y) * ch;
      ctx.fillStyle = "rgba(255,143,209,0.12)";
      ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      ctx.strokeStyle = "#ff8fd1";
      ctx.setLineDash([6, 4]);
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
      ctx.setLineDash([]);
    }

    // readout
    let txt = `${this.W} × ${this.H}`;
    const live = d?.mode === "draw" && d.moved ? { x0: Math.min(d.p0.x, d.p1.x), y0: Math.min(d.p0.y, d.p1.y), x1: Math.max(d.p0.x, d.p1.x), y1: Math.max(d.p0.y, d.p1.y) } : sel;
    if (live) {
      txt += `  ·  box: x ${Math.round(live.x0 * this.W)}, y ${Math.round(live.y0 * this.H)}, ${Math.round((live.x1 - live.x0) * this.W)} × ${Math.round((live.y1 - live.y0) * this.H)} px`;
    }
    this.el.dims.textContent = txt;
  }
}

function openEditor(node) {
  if (node.__mleEditor) return;
  const ed = new LayoutEditor(node);
  node.__mleEditor = ed;
  ed.open();
}

// ───────────────────────── registration ─────────────────────────

app.registerExtension({
  name: "moss.layout.editor",

  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData?.name !== NODE_NAME) return;

    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onNodeCreated?.apply(this, arguments);
      injectCSS();
      const node = this;

      hideWidget(getWidget(node, "layout_data"));

      const el = document.createElement("div");
      el.className = "mle-preview";
      el.innerHTML = `<button type="button">✏️ Open layout editor</button>
        <div class="mle-pv-wrap" title="Double-click to edit"><canvas></canvas></div>
        <div class="mle-pv-info"></div>`;
      const wrap = el.querySelector(".mle-pv-wrap");
      node.__mlePreview = { el, wrap, canvas: el.querySelector("canvas"), info: el.querySelector(".mle-pv-info") };
      el.querySelector("button").addEventListener("click", (e) => {
        e.stopPropagation();
        openEditor(node);
      });
      wrap.addEventListener("dblclick", (e) => {
        e.stopPropagation();
        openEditor(node);
      });
      // Keep pointer events on the preview from dragging the node around.
      el.addEventListener("pointerdown", (e) => e.stopPropagation());

      node.addDOMWidget("layout_preview", "moss_layout_preview", el, {
        serialize: false,
        hideOnZoom: false,
        getMinHeight: () => 200,
      });

      new ResizeObserver(() => schedulePreview(node)).observe(wrap);

      for (const name of ["width", "height", "summary", "layout_data"]) {
        const w = getWidget(node, name);
        if (!w) continue;
        const cb = w.callback;
        w.callback = function () {
          const res = cb?.apply(this, arguments);
          schedulePreview(node);
          return res;
        };
      }

      const [sw, sh] = node.size || [0, 0];
      node.setSize?.([Math.max(sw, 320), Math.max(sh, 520)]);
      schedulePreview(node);
      return r;
    };

    const onConfigure = nodeType.prototype.onConfigure;
    nodeType.prototype.onConfigure = function () {
      const r = onConfigure?.apply(this, arguments);
      hideWidget(getWidget(this, "layout_data"));
      schedulePreview(this);
      return r;
    };

    // Catch width/height coming in through links (or edits we didn't see).
    const onDrawForeground = nodeType.prototype.onDrawForeground;
    nodeType.prototype.onDrawForeground = function () {
      const r = onDrawForeground?.apply(this, arguments);
      const key = getDims(this).join("x") + "|" + (getWidget(this, "layout_data")?.value?.length ?? 0);
      if (key !== this.__mleKey) {
        this.__mleKey = key;
        schedulePreview(this);
      }
      return r;
    };

    const onRemoved = nodeType.prototype.onRemoved;
    nodeType.prototype.onRemoved = function () {
      this.__mleEditor?.close();
      return onRemoved?.apply(this, arguments);
    };

    const getExtraMenuOptions = nodeType.prototype.getExtraMenuOptions;
    nodeType.prototype.getExtraMenuOptions = function (_, options) {
      const r = getExtraMenuOptions?.apply(this, arguments);
      options?.unshift?.({ content: "Open layout editor", callback: () => openEditor(this) }, null);
      return r;
    };
  },
});
